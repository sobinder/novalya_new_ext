/*
 * 
 * SendMessageMembers Javascript
 * 
 * @since 5.0.0
 * 
 */
let SendMessageMembers;
(function($) {
    let $this;
    SendMessageMembers = {
        settings: {},
        initilaize: function() {
            $this = SendMessageMembers;
            $(document).ready(function() {                
                $this.onInitMethods();
            });
        },
        onInitMethods: function() {
        },
        shootMessage: function() {

        }
    };
    SendMessageMembers.initilaize();
})(jQuery);